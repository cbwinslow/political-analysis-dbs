# ChatGPT Conversation Exporter (CBW Edition)

Export ChatGPT conversations **right in the page** — Markdown, JSON, or a **ZIP of every code block** split by language.

## Options

You have **three** drop‑in options; pick your favorite:

1) **Chrome/Firefox Extension (recommended)**  
   - Go to `chrome://extensions` (or Firefox `about:debugging#/runtime/this-firefox`).
   - Enable *Developer mode*.
   - Click **Load unpacked** (Chrome) or **Load Temporary Add‑on** (Firefox) and select the `browser_extension/` folder.
   - Visit `https://chat.openai.com/c/<GUID>` or `https://chatgpt.com/c/<GUID>` and look for the floating **CBW Exporter** panel (bottom‑right).
   - Click **Export MD**, **Export JSON**, or **Export ZIP**.

   > NOTE: For ZIP export, this package includes a JSZip placeholder.  
   > For real ZIPs, replace `browser_extension/jszip.min.js` with the official JSZip build (https://stuk.github.io/jszip/).

2) **Tampermonkey userscript (super easy)**  
   - Install the **Tampermonkey** extension.
   - Create a new script and paste the contents of `tampermonkey/chatgpt-exporter.user.js`.
   - The same floating **CBW Exporter** panel will appear on ChatGPT pages.

3) **Bookmarklet (fastest one‑off)**  
   - Copy the single line from `scripts/export_chatgpt_dom_bookmarklet.txt`.
   - Create a new browser bookmark. Paste the code into the *URL* field.
   - On any ChatGPT conversation, click the bookmark to inject the exporter temporarily.

## Where are files saved?
- Markdown: `conversation-<GUID>-<timestamp>.md`
- JSON: `conversation-<GUID>-<timestamp>.json`
- ZIP: `snippets-<GUID>-<timestamp>.zip` (contains all code blocks + the Markdown and JSON).

## Robustness notes
- Uses multiple DOM strategies to find messages and code blocks.
- Works on both `chat.openai.com` and `chatgpt.com`.
- If the UI changes, the fallback still collects `pre > code` blocks.

## Power‑user tips
- The exporter auto‑detects languages from class names (e.g., `language-python`). Unknown types default to `.txt`.
- Works well with VS Code/Windsurf — the ZIP puts each snippet into its own file for easy diffing.

## Security
- Runs entirely client‑side. No network calls. No storage.
- Permissions are minimal.

— Built for CBW on 2025-09-09.
