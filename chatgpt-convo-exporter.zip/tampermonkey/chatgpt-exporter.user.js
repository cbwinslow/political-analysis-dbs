// ==UserScript==
// @name         ChatGPT Conversation Exporter (CBW Edition)
// @namespace    https://cloudcurio.cc/
// @version      1.0.0
// @description  Export ChatGPT conversations as Markdown/JSON/ZIP (code blocks split by language).
// @match        https://chat.openai.com/*
// @match        https://chatgpt.com/*
// @grant        none
// ==/UserScript==

(function() {
  'use strict';
  const add = (tag, attrs, parent=document.documentElement) => {
    const el = document.createElement(tag);
    if (attrs && attrs.textContent) { el.textContent = attrs.textContent; delete attrs.textContent; }
    Object.entries(attrs||{}).forEach(([k,v]) => el.setAttribute(k,v));
    parent.appendChild(el);
    return el;
  };
  add('style', {textContent: `#cbw-exporter-toolbar{position:fixed;right:18px;bottom:18px;z-index:999999;background:rgba(17,17,17,.9);color:#9efc8f;border:1px solid #0f0;border-radius:16px;padding:12px;font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;box-shadow:0 6px 20px rgba(0,0,0,.3)}#cbw-exporter-toolbar .cbw-title{font-weight:700;letter-spacing:.5px;margin-bottom:6px;font-size:13px}#cbw-exporter-toolbar .cbw-row{margin:6px 0;display:flex;gap:8px;align-items:center}#cbw-exporter-toolbar button{border-radius:10px;border:1px solid #2affaa;background:rgba(10,40,10,.7);color:#aefcb0;padding:6px 10px;font-size:12px;cursor:pointer}#cbw-exporter-toolbar button:hover{filter:brightness(1.2)}#cbw-exporter-toolbar label{font-size:12px;cursor:pointer}#cbw-exporter-toolbar .cbw-status{font-size:12px;opacity:.9;margin-left:auto}`});
  const s = add('script', {src: 'https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js'});
  s.onload = () => {
    const core = document.createElement('script');
    core.textContent = (() => {
      /* CONTENT_JS */
      /*
       * File: content.js
       * Author: ChatGPT for CBW
       * Date: 2025-09-09
       * Summary:
       *   Injects a floating toolbar into ChatGPT pages (chat.openai.com/chatgpt.com) to export conversations.
       *   Exports: Markdown, JSON, and ZIP of all code blocks (split/typed by language).
       *   Robust DOM scanning using multiple strategies to survive UI changes.
       *
       * Inputs:
       *   - Current DOM of the ChatGPT conversation page.
       * Outputs:
       *   - Triggers downloads (Blob URLs) for .md, .json, and .zip files.
       *
       * Security:
       *   - No external network calls.
       *   - No storage access.
       *   - Runs on matched domains only.
       *
       * Notes:
       *   - ZIP functionality relies on bundled JSZip.
       *   - If DOM changes significantly, the fallback mode still captures pre>code blocks.
       *
       * Modification Log:
       *   - 1.0.0: Initial release.
       */
      (function () {
        "use strict";

        // ===== Utilities =====
        const log = (...args) => console.log("[CBW-Exporter]", ...args);
        const err = (...args) => console.error("[CBW-Exporter]", ...args);

        function makeFileName(prefix, ext) {
          const id = (getConversationId() || "chat") + "-" + new Date().toISOString().replace(/[^\dT]/g, "").slice(0,15);
          return `${prefix}-${id}.${ext}`;
        }

        function getConversationId() {
          try {
            // chat.openai.com/c/{GUID} OR chatgpt.com/c/{GUID}
            const m = window.location.pathname.match(/\/c\/([a-f0-9-]+)/i);
            if (m && m[1]) return m[1];
          } catch (e) {}
          return null;
        }

        function getRoleFromNode(node) {
          // Try ARIA role/name, otherwise heuristic via text
          try {
            const aria = node.getAttribute?.("data-message-author-role") || node.getAttribute?.("data-author-role");
            if (aria) return aria;
          } catch (e) {}
          // Fallback: look for name labels commonly used in UI
          const txt = node.textContent || "";
          if (/you/i.test(txt) && /copy/.test(txt) === false) return "user";
          if (/gpt/i.test(txt) || /assistant/i.test(txt)) return "assistant";
          return "unknown";
        }

        function sanitizeFileBase(s) {
          return (s || "snippet").replace(/[^\w.-]+/g, "_").slice(0, 80) || "snippet";
        }

        function detectLang(codeEl) {
          // Look for className like "language-python", "lang-js", data-language, etc.
          const classList = [...(codeEl.classList || [])].join(" ");
          const parentClassList = [...(codeEl.parentElement?.classList || [])].join(" ");
          const dataLang = codeEl.getAttribute?.("data-language") || codeEl.parentElement?.getAttribute?.("data-language") || "";
          const hints = (classList + " " + parentClassList + " " + dataLang).toLowerCase();

          const known = [
            "bash","shell","sh","zsh","python","py","javascript","js","typescript","ts","json","yaml","yml","toml","ini",
            "html","xml","css","sql","go","rust","java","kotlin","scala","c","cpp","csharp","php","ruby","lua","r","dart","powershell","ps1","makefile","dockerfile"
          ];
          for (const k of known) {
            if (hints.includes("language-" + k) || hints.includes("lang-" + k) || hints.includes(k + " ")) return k;
          }
          // Try markdown fence detection ```lang as title attribute or preceding node text
          const possible = codeEl.getAttribute?.("class") || "";
          if (/markdown/.test(possible)) return "markdown";
          return "text";
        }

        function collectMessages() {
          // Try multiple selectors to support UI changes
          // Primary blocks often are article elements or divs with role="presentation" etc.
          const candidates = Array.from(document.querySelectorAll("main, .overflow-hidden, .flex, article, [data-message-author-role], [data-author-role]"));
          const msgs = [];
          const seen = new Set();

          // Helper: Pull all code blocks within a container
          function extractCodeSnippets(container) {
            const snippets = [];
            const codes = container.querySelectorAll("pre code, code.hljs, div[data-language] pre code");
            codes.forEach((codeEl, idx) => {
              try {
                const lang = detectLang(codeEl);
                const raw = codeEl.textContent || "";
                if (raw.trim().length === 0) return;
                snippets.push({
                  index: idx,
                  language: lang,
                  content: raw
                });
              } catch (e) {
                err("Code extraction error:", e);
              }
            });
            return snippets;
          }

          // Helper: Pull plain text (excluding code)
          function extractPlainText(container) {
            try {
              // Clone and remove code to avoid duplication
              const clone = container.cloneNode(true);
              clone.querySelectorAll("pre, code").forEach(n => n.remove());
              const text = clone.innerText || clone.textContent || "";
              return text.trim();
            } catch (e) {
              return "";
            }
          }

          // Identify message containers
          const messageBlocks = Array.from(document.querySelectorAll('[data-message-author-role], [data-author-role]'));
          const blocks = messageBlocks.length ? messageBlocks : candidates;

          blocks.forEach((node) => {
            try {
              if (seen.has(node)) return;
              seen.add(node);

              // Heuristic: consider nodes that actually contain content (code or significant text)
              const hasCode = node.querySelector && node.querySelector("pre code");
              const text = (node.innerText || "").trim();
              if (!hasCode && (!text || text.length < 20)) return;

              const role = getRoleFromNode(node);
              const code = extractCodeSnippets(node);
              const plain = extractPlainText(node);

              if (code.length || plain) {
                msgs.push({ role, text: plain, code });
              }
            } catch (e) {
              // ignore
            }
          });

          // Fallback: If nothing found, just gather all visible code blocks
          if (msgs.length === 0) {
            const codeBlocks = Array.from(document.querySelectorAll("pre code"));
            if (codeBlocks.length) {
              msgs.push({
                role: "assistant",
                text: "",
                code: codeBlocks.map((c, i) => ({ index: i, language: detectLang(c), content: c.textContent || "" }))
              });
            }
          }

          return msgs;
        }

        function toMarkdown(msgs) {
          const parts = [];
          const convoId = getConversationId();
          if (convoId) {
            parts.push(`# Conversation ${convoId}\n`);
          }
          msgs.forEach((m, i) => {
            parts.push(`## ${m.role || "unknown"} ${i+1}`);
            if (m.text) parts.push(m.text);
            (m.code || []).forEach(sn => {
              parts.push(`\n\`\`\`${sn.language || ""}\n${sn.content}\n\`\`\``);
            });
            parts.push("");
          });
          return parts.join("\n");
        }

        function toJSON(msgs) {
          return JSON.stringify({
            conversation_id: getConversationId(),
            exported_at: new Date().toISOString(),
            message_count: msgs.length,
            messages: msgs
          }, null, 2);
        }

        async function createZipOfCode(msgs) {
          if (typeof JSZip === "undefined") {
            alert("JSZip not loaded; cannot create ZIP. Try Markdown/JSON export instead.");
            throw new Error("JSZip missing");
          }
          const zip = new JSZip();
          let fileIdx = 1;
          msgs.forEach((m, mi) => {
            (m.code || []).forEach((sn) => {
              const lang = sn.language || "text";
              const base = sanitizeFileBase(`${String(fileIdx).padStart(3,"0")}_${lang}_snippet`);
              const extMap = {
                bash:"sh",shell:"sh",sh:"sh",zsh:"zsh",python:"py",py:"py",javascript:"js",js:"js",typescript:"ts",ts:"ts",
                json:"json",yaml:"yml",yml:"yml",toml:"toml",ini:"ini",html:"html",xml:"xml",css:"css",sql:"sql",go:"go",
                rust:"rs",java:"java",kotlin:"kt",scala:"scala",c:"c",cpp:"cpp",csharp:"cs",php:"php",ruby:"rb",lua:"lua",r:"r",
                dart:"dart",powershell:"ps1","ps1":"ps1","makefile":"mk","dockerfile":"dockerfile",markdown:"md",text:"txt"
              };
              const ext = extMap[lang] || "txt";
              const fname = `${base}.${ext}`;
              zip.file(fname, sn.content || "");
              fileIdx++;
            });
          });
          // Include metadata & a README
          const md = toMarkdown(msgs);
          const jj = toJSON(msgs);
          zip.file("README.md", "# Exported code snippets\n\nThis archive was generated by the CBW Conversation Exporter.\n- `snippets/*` would normally go here, but to keep it flat we store files at root\n- Also included: `conversation.md` and `conversation.json`\n");
          zip.file("conversation.md", md);
          zip.file("conversation.json", jj);
          const blob = await zip.generateAsync({ type: "blob" });
          return blob;
        }

        function downloadBlob(blob, filename) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = filename;
          document.body.appendChild(a);
          a.click();
          setTimeout(() => {
            URL.revokeObjectURL(url);
            a.remove();
          }, 0);
        }

        // ===== UI Toolbar =====
        function injectToolbar() {
          if (document.getElementById("cbw-exporter-toolbar")) return;
          const bar = document.createElement("div");
          bar.id = "cbw-exporter-toolbar";
          bar.innerHTML = `
            <div class="cbw-title">CBW Exporter</div>
            <div class="cbw-row">
              <button id="cbw-export-md" title="Export conversation as Markdown">Export MD</button>
              <button id="cbw-export-json" title="Export conversation as JSON">Export JSON</button>
              <button id="cbw-export-zip" title="Export all code blocks as ZIP and include MD/JSON">Export ZIP</button>
            </div>
            <div class="cbw-row">
              <label><input type="checkbox" id="cbw-autoscan" checked /> Autoscan</label>
              <span class="cbw-status" id="cbw-status">Ready</span>
            </div>
          `;
          document.documentElement.appendChild(bar);

          const btnMD = bar.querySelector("#cbw-export-md");
          const btnJSON = bar.querySelector("#cbw-export-json");
          const btnZIP = bar.querySelector("#cbw-export-zip");
          const status = bar.querySelector("#cbw-status");
          const autoscan = bar.querySelector("#cbw-autoscan");

          function updateStatus(text) { if (status) status.textContent = text; }

          async function run(kind) {
            try {
              updateStatus("Scanning…");
              const msgs = collectMessages();
              updateStatus(`Found ${msgs.length} message(s)`);
              if (kind === "md") {
                const blob = new Blob([toMarkdown(msgs)], { type: "text/markdown" });
                downloadBlob(blob, makeFileName("conversation", "md"));
              } else if (kind === "json") {
                const blob = new Blob([toJSON(msgs)], { type: "application/json" });
                downloadBlob(blob, makeFileName("conversation", "json"));
              } else if (kind === "zip") {
                const blob = await createZipOfCode(msgs);
                downloadBlob(blob, makeFileName("snippets", "zip"));
              }
              updateStatus("Done");
            } catch (e) {
              console.error(e);
              updateStatus("Error – see console");
              alert("Exporter error. Open DevTools console for details.");
            }
          }

          btnMD?.addEventListener("click", () => run("md"));
          btnJSON?.addEventListener("click", () => run("json"));
          btnZIP?.addEventListener("click", () => run("zip"));

          // Autoscan to refresh internal cache (currently used only for status)
          if (autoscan) {
            let t = null;
            autoscan.addEventListener("change", () => {
              if (autoscan.checked) start();
              else stop();
            });
            function scan() {
              try {
                const msgs = collectMessages();
                updateStatus(`Autoscan: ${msgs.length} message(s)`);
              } catch {}
            }
            function start() {
              if (t) return;
              t = setInterval(scan, 5000);
              scan();
            }
            function stop() { if (t) { clearInterval(t); t = null; updateStatus("Paused"); } }
            start();
          }
        }

        // Wait for page ready, then inject
        const ready = () => injectToolbar();
        if (document.readyState === "complete" || document.readyState === "interactive") {
          setTimeout(ready, 800);
        } else {
          document.addEventListener("DOMContentLoaded", ready, { once: true });
        }
      })();
      /* END CONTENT_JS */
    }).toString().replace(/^.*?\{\/\*|\*\/\}$/g, '');
    document.documentElement.appendChild(core);
  };
})();